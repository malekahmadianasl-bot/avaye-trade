@echo off
if not exist "%~dp0gradle\wrapper\gradle-wrapper.jar" (echo Gradle wrapper JAR is not bundled; use a Gradle/Android cloud builder or install Gradle 8.11.1.& exit /b 2)
java -jar "%~dp0gradle\wrapper\gradle-wrapper.jar" %*
