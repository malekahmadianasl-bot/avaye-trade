package ir.avayetrade.app

import android.app.Activity
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var connectionSummary: TextView
    private lateinit var marketText: TextView
    private lateinit var accountText: TextView
    private lateinit var positionsText: TextView
    private lateinit var scoreText: TextView
    private lateinit var setupText: TextView
    private lateinit var backendInput: EditText
    private var stopped = true
    private var client: BackendClient? = null

    private val bg=Color.rgb(15,23,42); private val card=Color.rgb(30,41,59); private val white=Color.rgb(248,250,252)
    private val muted=Color.rgb(148,163,184); private val accent=Color.rgb(245,158,11); private val danger=Color.rgb(185,28,28)

    override fun onCreate(b:Bundle?){super.onCreate(b);tts=TextToSpeech(this,this);buildUi()}
    override fun onDestroy(){client?.shutdown();tts.stop();tts.shutdown();super.onDestroy()}
    private fun tv(s:String,size:Float,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(white);setPadding(16,12,16,12);if(bold)typeface=Typeface.DEFAULT_BOLD}
    private fun box()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(8,8,8,8);setBackgroundColor(card)}
    private fun lp()=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,10)}
    private fun field(h:String)=EditText(this).apply{hint=h;setTextColor(white);setHintTextColor(muted);textSize=17f;setSingleLine(true);setPadding(18,14,18,14);setBackgroundColor(Color.rgb(51,65,85))}
    private fun button(t:String)=Button(this).apply{text=t;textSize=17f}

    private fun buildUi(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,18);setBackgroundColor(bg)}
        val scroll=ScrollView(this).apply{addView(root)}
        root.addView(tv("آوای ترید",30f,true).apply{gravity=Gravity.RIGHT})
        root.addView(tv("دستیار صوتی معامله‌گری • XAUUSD • MT5",15f).apply{setTextColor(muted);gravity=Gravity.RIGHT})

        val net=box();net.addView(tv("۱. اتصال امن به Backend",20f,true))
        backendInput=field("آدرس Backend، مثال: https://api.example.com"); net.addView(backendInput)
        net.addView(button("بررسی سلامت Backend").apply{setOnClickListener{connectBackend()}})
        connectionSummary=tv("وضعیت: متصل نیست",16f);connectionSummary.setTextColor(muted);net.addView(connectionSummary);root.addView(net,lp())

        val market=box();market.addView(tv("۲. داده زنده بازار",20f,true))
        marketText=tv("XAUUSD: —\nH1: —   M15: —   M5: —",17f);market.addView(marketText)
        scoreText=tv("امتیاز سیگنال: — / 100",22f,true);market.addView(scoreText)
        setupText=tv("Setup: NO_TRADE — تا دریافت داده معتبر",16f);market.addView(setupText)
        market.addView(button("دریافت داده بازار").apply{setOnClickListener{loadMarket()}})
        root.addView(market,lp())

        val account=box();account.addView(tv("۳. حساب و معاملات",20f,true))
        accountText=tv("Balance: —\nEquity: —\nMargin: —",16f);account.addView(accountText)
        positionsText=tv("معاملات باز: —",16f);account.addView(positionsText)
        account.addView(button("به‌روزرسانی حساب و معاملات").apply{setOnClickListener{loadAccount();loadPositions()}})
        root.addView(account,lp())

        val risk=box();risk.addView(tv("۴. کنترل ریسک",20f,true));risk.addView(tv("ریسک نمونه: ۰٫۵٪ | حد زیان روزانه: ۲٪ | حداقل RR: 1:1.5",16f));risk.addView(tv("گیت‌های سخت ریسک، خبر، اسپرد، مارجین و مجوز معامله قابل دور زدن نیستند.",15f));root.addView(risk,lp())

        root.addView(button("🎙 فرمان صوتی").apply{textSize=21f;setTextColor(Color.WHITE);setBackgroundColor(accent);contentDescription="فرمان صوتی آوای ترید";setOnClickListener{listen()}},lp())
        root.addView(button("⛔ توقف اضطراری معاملات جدید").apply{textSize=19f;setTextColor(Color.WHITE);setBackgroundColor(danger);setOnClickListener{stopped=true;connectionSummary.text="توقف اضطراری فعال است";speak("توقف اضطراری فعال شد. معامله جدید مجاز نیست.")}},lp())
        root.addView(tv("Real Trading تا تکمیل Backend، احراز هویت، کنترل ریسک، تأیید دومرحله‌ای و تست Demo قفل است.",15f,true).apply{gravity=Gravity.CENTER})
        setContentView(scroll)
    }

    private fun connectBackend(){
        val base=backendInput.text.toString().trim()
        if(base.isBlank()){speak("آدرس Backend را وارد کنید.");return}
        connectionSummary.text="در حال بررسی اتصال..."
        client?.shutdown(); client=BackendClient(base)
        client!!.get("health", object: BackendClient.Callback{override fun done(ok:Boolean,body:String){runOnUiThread{
            connectionSummary.text=if(ok)"Backend: متصل و پاسخ‌گو" else "Backend: خطا — ${BackendClient.compact(body)}"
            speak(if(ok)"اتصال Backend برقرار است." else "اتصال Backend برقرار نشد.")
        }}})
    }
    private fun loadMarket(){val c=client?:run{speak("ابتدا Backend را متصل کنید.");return};marketText.text="در حال دریافت داده...";c.get("market/xauusd",object:BackendClient.Callback{override fun done(ok:Boolean,body:String){runOnUiThread{if(!ok){marketText.text="داده بازار: دریافت نشد\n${BackendClient.compact(body)}";return};try{val o=JSONObject(body);val price=o.optDouble("price",Double.NaN);val h1=o.optString("h1","—");val m15=o.optString("m15","—");val m5=o.optString("m5","—");val score=o.optInt("score",-1);val setup=o.optString("setup","NO_TRADE");marketText.text="XAUUSD: ${if(price.isNaN())"—" else price}\nH1: $h1   M15: $m15   M5: $m5";scoreText.text="امتیاز سیگنال: ${if(score>=0)score else "—"} / 100";setupText.text="Setup: $setup"}catch(_:Exception){marketText.text="پاسخ Backend معتبر نیست."}}}})}
    private fun loadAccount(){val c=client?:run{ speak("ابتدا Backend را متصل کنید.");return };c.get("account",object:BackendClient.Callback{override fun done(ok:Boolean,body:String){runOnUiThread{accountText.text=if(!ok)"حساب: دریافت نشد" else try{val o=JSONObject(body);"Balance: ${o.optString("balance","—")}\nEquity: ${o.optString("equity","—")}\nMargin: ${o.optString("margin","—")}"}catch(_:Exception){"پاسخ حساب نامعتبر است."}}}})}
    private fun loadPositions(){val c=client?:return;c.get("positions",object:BackendClient.Callback{override fun done(ok:Boolean,body:String){runOnUiThread{positionsText.text=if(!ok)"معاملات باز: دریافت نشد" else "معاملات باز: ${try{JSONObject(body).optInt("count",0)}catch(_:Exception){"پاسخ نامعتبر"}}"}}})}
    private fun listen(){val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE,"fa-IR");putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_PROMPT,"فرمان خود را بگویید")};try{startActivityForResult(i,100)}catch(_:Exception){speak("تشخیص گفتار در این دستگاه در دسترس نیست.")}}
    override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r!=100||c!=RESULT_OK)return;val h=d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?:return;handleCommand(h)}
    private fun handleCommand(raw:String){val q=raw.replace("‌","").trim().lowercase(Locale("fa","IR"));when{q.contains("توقف")||q.contains("غیرفعال")-> {stopped=true;speak("توقف معاملات جدید فعال شد.")};q.contains("قیمت")&&q.contains("طلا")->loadMarket();q.contains("تحلیل")&&q.contains("طلا")->loadMarket();q.contains("معاملات باز")->loadPositions();q.contains("وضعیت حساب")->loadAccount();q.contains("معامله جدید")||q.contains("خرید")||q.contains("فروش")->speak("معامله واقعی قفل است و بدون کنترل ریسک و دو تأیید مستقل ارسال نمی‌شود.");else->speak("فرمان را متوجه نشدم. قیمت طلا، تحلیل طلا، معاملات باز، وضعیت حساب یا توقف معاملات را بگویید.")}}
    override fun onInit(r:Int){if(r==TextToSpeech.SUCCESS){val x=tts.setLanguage(Locale("fa","IR"));if(x==TextToSpeech.LANG_MISSING_DATA||x==TextToSpeech.LANG_NOT_SUPPORTED)tts.language=Locale.US}}
    private fun speak(s:String){if(::tts.isInitialized)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"avaye-trade")}
}
