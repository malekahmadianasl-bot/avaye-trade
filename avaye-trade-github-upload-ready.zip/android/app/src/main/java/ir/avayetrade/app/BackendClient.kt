package ir.avayetrade.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class BackendClient(private val baseUrl: String) {
    private val executor = Executors.newSingleThreadExecutor()

    interface Callback { fun done(ok: Boolean, body: String) }

    fun get(path: String, cb: Callback) {
        executor.execute {
            var c: HttpURLConnection? = null
            try {
                val url = URL(baseUrl.trimEnd('/') + "/" + path.trimStart('/'))
                c = url.openConnection() as HttpURLConnection
                c.requestMethod = "GET"
                c.connectTimeout = 5000
                c.readTimeout = 7000
                c.setRequestProperty("Accept", "application/json")
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
                cb.done(code in 200..299, body)
            } catch (e: Exception) {
                cb.done(false, e.message ?: "network_error")
            } finally { c?.disconnect() }
        }
    }

    fun shutdown() { executor.shutdownNow() }

    companion object {
        fun compact(body: String): String = try {
            val o = JSONObject(body)
            when {
                o.has("status") -> o.optString("status")
                o.has("message") -> o.optString("message")
                else -> body.take(180)
            }
        } catch (_: Exception) { body.take(180) }
    }
}
