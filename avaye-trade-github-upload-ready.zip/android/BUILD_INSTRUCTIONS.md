# Avaye Trade v2.0.0 — Build Ready

Requires JDK 17, Android SDK 35, Gradle 8.11.1, AGP 8.7.3 and Kotlin 2.0.21.

From `android`: `gradle assembleDebug`

Expected APK: `app/build/outputs/apk/debug/app-debug.apk`

Real trading is intentionally locked. This package is for Demo/build validation.
