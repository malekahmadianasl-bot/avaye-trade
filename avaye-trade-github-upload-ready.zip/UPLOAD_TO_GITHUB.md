# آوای ترید — آماده‌سازی Repository

این پوشه برای قرار دادن در مخزن:
malekahmadianasl-bot/avaye-trade

ساختار مهم:
- android/ : اپ اندروید
- backend/ : API اولیه
- bridge/ : اتصال اولیه MT5
- .github/workflows/android-apk.yml : ساخت خودکار APK

## آپلود
محتویات داخل این پوشه را در ریشه Repository قرار دهید؛
یعنی فایل `README.md` باید مستقیماً در ریشه مخزن باشد و پوشه‌های
`android`, `backend`, `bridge`, `.github` نیز مستقیماً در ریشه باشند.

## Build
پس از Push به شاخه `main`، GitHub Actions باید Workflow با نام
`Build Avaye Trade APK` را اجرا کند.

APK خروجی:
`android/app/build/outputs/apk/debug/app-debug.apk`

این نسخه Debug است و برای تست اولیه ساخته می‌شود؛
برای انتشار نهایی، signing/release جداگانه لازم است.
