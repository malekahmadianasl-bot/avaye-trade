from fastapi import FastAPI
from .mt5.adapter import MT5ReadOnlyAdapter

app = FastAPI(title="Avaye Trade MT5 Bridge", version="0.18.0")
adapter = MT5ReadOnlyAdapter()

@app.on_event("startup")
def startup():
    adapter.connect()
    adapter.discover_gold_symbol()

@app.get("/health")
def health():
    return {"ok": True, "mt5_connected": adapter.connected, "symbol": adapter.symbol, "trading_enabled": False}

@app.get("/market/tick")
def tick():
    return adapter.tick()

@app.get("/market/candles")
def candles(timeframe: str = "M5", count: int = 200):
    return adapter.candles(timeframe, count)

@app.get("/account")
def account():
    return adapter.account()

@app.get("/positions")
def positions():
    return adapter.positions()
