from datetime import datetime, timezone
from typing import Any

try:
    import MetaTrader5 as mt5
except ImportError:  # keeps development imports possible off Windows
    mt5 = None

TIMEFRAMES = {"M5": "TIMEFRAME_M5", "M15": "TIMEFRAME_M15", "H1": "TIMEFRAME_H1"}

class MT5ReadOnlyAdapter:
    def __init__(self) -> None:
        self.connected = False
        self.symbol = None

    def connect(self) -> dict[str, Any]:
        if mt5 is None:
            return {"connected": False, "reason": "MetaTrader5 package unavailable"}
        ok = mt5.initialize()
        self.connected = bool(ok)
        return {"connected": self.connected, "reason": None if ok else str(mt5.last_error())}

    def discover_gold_symbol(self) -> str | None:
        if not self.connected or mt5 is None:
            return None
        candidates = []
        for s in mt5.symbols_get() or []:
            name = s.name.upper()
            if "XAUUSD" in name or name == "GOLD":
                candidates.append(s)
        if not candidates:
            return None
        # Prefer exact XAUUSD, then the shortest matching broker suffix.
        candidates.sort(key=lambda s: (s.name.upper() != "XAUUSD", len(s.name)))
        chosen = candidates[0]
        if not chosen.visible:
            mt5.symbol_select(chosen.name, True)
        self.symbol = chosen.name
        return self.symbol

    def tick(self) -> dict[str, Any]:
        if mt5 is None or not self.connected:
            return {"connected": False, "symbol": self.symbol, "bid": None, "ask": None, "spread_points": None}
        symbol = self.symbol or self.discover_gold_symbol()
        if not symbol:
            return {"connected": True, "symbol": None, "bid": None, "ask": None, "spread_points": None}
        t = mt5.symbol_info_tick(symbol)
        info = mt5.symbol_info(symbol)
        if t is None:
            return {"connected": True, "symbol": symbol, "bid": None, "ask": None, "spread_points": None}
        spread = None
        if info and info.point:
            spread = (t.ask - t.bid) / info.point
        return {"connected": True, "symbol": symbol, "bid": t.bid, "ask": t.ask,
                "spread_points": spread, "timestamp": datetime.now(timezone.utc).isoformat()}

    def candles(self, timeframe: str, count: int = 200) -> dict[str, Any]:
        if mt5 is None or not self.connected:
            return {"connected": False, "symbol": self.symbol, "timeframe": timeframe, "candles": []}
        symbol = self.symbol or self.discover_gold_symbol()
        tf_name = TIMEFRAMES.get(timeframe.upper())
        if not symbol or not tf_name:
            return {"connected": True, "symbol": symbol, "timeframe": timeframe, "candles": []}
        tf = getattr(mt5, tf_name)
        rates = mt5.copy_rates_from_pos(symbol, tf, 0, max(1, min(count, 1000)))
        candles = [] if rates is None else [
            {"time": int(r[0]), "open": float(r[1]), "high": float(r[2]), "low": float(r[3]),
             "close": float(r[4]), "tick_volume": int(r[5])} for r in rates
        ]
        return {"connected": True, "symbol": symbol, "timeframe": timeframe, "candles": candles}

    def account(self) -> dict[str, Any]:
        if mt5 is None or not self.connected:
            return {"connected": False, "balance": None, "equity": None, "margin": None, "free_margin": None}
        a = mt5.account_info()
        if a is None:
            return {"connected": True, "balance": None, "equity": None, "margin": None, "free_margin": None}
        return {"connected": True, "balance": a.balance, "equity": a.equity, "margin": a.margin, "free_margin": a.margin_free,
                "currency": a.currency, "login": a.login}

    def positions(self) -> dict[str, Any]:
        if mt5 is None or not self.connected:
            return {"connected": False, "positions": []}
        ps = mt5.positions_get() or []
        return {"connected": True, "positions": [
            {"ticket": int(p.ticket), "symbol": p.symbol, "type": int(p.type), "volume": float(p.volume),
             "price_open": float(p.price_open), "sl": float(p.sl), "tp": float(p.tp), "profit": float(p.profit)}
            for p in ps
        ]}
