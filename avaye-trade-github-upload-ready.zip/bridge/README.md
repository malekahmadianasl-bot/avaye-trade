# Avaye Trade MT5 Bridge v0.18

Windows-only read-only MT5 adapter. It discovers the broker's gold symbol, reads ticks/candles/account/positions, and **never places trades**.

Run beside a logged-in MT5 terminal:

```text
pip install -r requirements.txt
uvicorn app.main:app --host 127.0.0.1 --port 8010
```

Real trading is deliberately disabled.
