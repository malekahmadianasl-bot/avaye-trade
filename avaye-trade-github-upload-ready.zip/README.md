# آوای ترید — Avaye Trade

## v2.0.0 Build-Ready
Android voice-first trading assistant. Android is configured for SDK 35, JDK 17, AGP 8.7.3, Kotlin 2.0.21 and Gradle 8.11.1.

Real trading is intentionally locked. This is not a claim of live-trading readiness.
