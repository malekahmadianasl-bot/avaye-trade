# Avaye Trade Backend v0.17

Development-safe FastAPI service. It never accepts or stores the MT5 password and never places trades.
Production data must come from the Windows MT5 Bridge over an authenticated private channel.
