
from datetime import datetime, timezone
import os, httpx
from fastapi import FastAPI, HTTPException
from .strategy.engine import analyse

app=FastAPI(title="Avaye Trade Backend",version="0.19.0")
BRIDGE_URL=os.getenv("BRIDGE_URL","http://127.0.0.1:8010")

async def bridge_get(path,params=None):
    try:
        async with httpx.AsyncClient(timeout=5) as c:
            r=await c.get(f"{BRIDGE_URL}{path}",params=params); r.raise_for_status(); return r.json()
    except Exception as e: raise HTTPException(503,detail=f"MT5 bridge unavailable: {e}")

@app.get("/health")
def health(): return {"ok":True,"service":"backend","version":"0.19.0","timestamp":datetime.now(timezone.utc).isoformat()}

@app.get("/api/v1/market/xauusd")
async def xauusd():
    tick=await bridge_get("/market/tick")
    out={"symbol":tick.get("symbol"),"bid":tick.get("bid"),"ask":tick.get("ask"),
         "price":tick.get("bid"),"spread_points":tick.get("spread_points"),
         "timestamp":tick.get("timestamp"),"score":0,"setup":"NO_TRADE","direction":"NONE"}
    try:
        h1=await bridge_get("/market/candles",{"timeframe":"H1","count":220})
        m15=await bridge_get("/market/candles",{"timeframe":"M15","count":100})
        m5=await bridge_get("/market/candles",{"timeframe":"M5","count":100})
        sig=analyse(h1.get("candles",[]),m15.get("candles",[]),m5.get("candles",[]),tick.get("spread_points"))
        out.update(sig)
    except Exception as e: out["analysis_error"]=str(e)
    return out

@app.get("/api/v1/market/candles")
async def market_candles(timeframe:str="M5",count:int=200):
    tf=timeframe.upper()
    if tf not in {"M5","M15","H1"}: raise HTTPException(400,"Unsupported timeframe")
    return await bridge_get("/market/candles",{"timeframe":tf,"count":count})

@app.get("/api/v1/account")
async def account(): return await bridge_get("/account")

@app.get("/api/v1/positions")
async def positions():
    p=await bridge_get("/positions"); p["count"]=len(p.get("positions",[])); return p
