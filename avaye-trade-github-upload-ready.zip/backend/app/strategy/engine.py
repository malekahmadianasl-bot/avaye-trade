
from __future__ import annotations
from dataclasses import dataclass
from typing import Any

def ema(values, period):
    if len(values) < period: return []
    k=2/(period+1); out=[sum(values[:period])/period]
    for v in values[period:]: out.append(v*k+out[-1]*(1-k))
    return out

def rsi(values, period=14):
    if len(values)<=period: return []
    gains=[]; losses=[]
    for a,b in zip(values[:-1],values[1:]):
        d=b-a; gains.append(max(d,0)); losses.append(max(-d,0))
    ag=sum(gains[:period])/period; al=sum(losses[:period])/period
    out=[100 if al==0 else 100-100/(1+ag/al)]
    for i in range(period,len(gains)):
        ag=(ag*(period-1)+gains[i])/period; al=(al*(period-1)+losses[i])/period
        out.append(100 if al==0 else 100-100/(1+ag/al))
    return out

def atr(candles, period=14):
    if len(candles)<=period: return []
    tr=[]
    for i,c in enumerate(candles):
        if i==0: tr.append(c["high"]-c["low"])
        else: tr.append(max(c["high"]-c["low"],abs(c["high"]-candles[i-1]["close"]),abs(c["low"]-candles[i-1]["close"])))
    out=[sum(tr[1:period+1])/period]
    for i in range(period+1,len(tr)):
        out.append((out[-1]*(period-1)+tr[i])/period)
    return out

def analyse(h1,m15,m5,spread_points=None):
    def closes(c): return [x["close"] for x in c]
    c1,c2,c3=closes(h1),closes(m15),closes(m5)
    if len(c1)<210 or len(c2)<60 or len(c3)<60:
        return {"score":0,"setup":"NO_TRADE","direction":"NONE","reasons":["داده کافی نیست"]}
    e20,e50,e200=ema(c1,20),ema(c1,50),ema(c1,200)
    trend=20 if e20[-1]>e50[-1]>e200[-1] else 0
    trend_sell=20 if e20[-1]<e50[-1]<e200[-1] else 0
    r=rsi(c3)[-1]; m5e20=ema(c3,20)[-1]; m5e50=ema(c3,50)[-1]
    momentum=10 if c3[-1]>m5e20 else 0
    momentum_sell=10 if c3[-1]<m5e20 else 0
    score=trend+momentum
    direction="BUY" if score>=20 else "SELL" if trend_sell+momentum_sell>=20 else "NONE"
    if direction=="SELL": score=trend_sell+momentum_sell
    if 40<r<60: score=max(0,score-5)
    setup="VALID_SIGNAL" if score>=70 else "WATCH" if score>=60 else "NO_TRADE"
    return {"score":score,"setup":setup,"direction":direction,
            "rsi":round(r,2),"ema20":round(e20[-1],5),"ema50":round(e50[-1],5),
            "ema200":round(e200[-1],5),"spread_points":spread_points,
            "reasons":["روند H1","مومنتوم M5","RSI M5"],"note":"این امتیاز پژوهشی است و مجوز معامله نیست."}
